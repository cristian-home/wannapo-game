import{_ as e,o as c,c as s}from"./index-DVss1fbH.js";const t={};function n(o,r){return c(),s("h1",null,"Results View")}const a=e(t,[["render",n]]);export{a as default};
