import{_ as e,o as c,c as o}from"./index-DVss1fbH.js";const t={};function n(a,r){return c(),o("h1",null,"This is an about page")}const _=e(t,[["render",n]]);export{_ as default};
