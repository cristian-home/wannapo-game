import{_ as e,o,c}from"./index-DVss1fbH.js";const n={};function t(r,_){return o(),c("h1",null,"Page Not Found")}const s=e(n,[["render",t]]);export{s as default};
